var searchData=
[
  ['_5fcalculation_0',['_calculation',['../class_stack.html#a3d71197491c3e08f55a7a4964d888b92',1,'Stack']]],
  ['_5ftype_5fname_1',['_type_name',['../class_stack.html#a10d4f809cbb6cc0bdd4a17d7b7d7d4b1',1,'Stack']]],
  ['_5fvalues_2',['_values',['../class_stack.html#ab9b00394cf869f270fddfb46fdfab592',1,'Stack']]]
];
