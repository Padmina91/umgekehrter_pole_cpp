var searchData=
[
  ['check_5fvector_5ftype_5fmatches_5ftype_5fname_4',['check_vector_type_matches_type_name',['../class_stack.html#aec914b2fee6972a2a77e75ce3dd8fea5',1,'Stack']]]
];
