var searchData=
[
  ['stack_56',['Stack',['../class_stack.html',1,'']]]
];
