var searchData=
[
  ['remove_5funnecessary_5fwhitespace_80',['remove_unnecessary_whitespace',['../class_stack.html#ab0d8af00dc5ef5c6b1883f9412a7eb9f',1,'Stack']]]
];
