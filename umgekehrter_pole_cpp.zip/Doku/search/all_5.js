var searchData=
[
  ['get_5fcalculation_12',['get_calculation',['../class_stack.html#af7b2971b980c3eb04043397092fb0519',1,'Stack']]],
  ['get_5fresult_13',['get_result',['../class_stack.html#a6611b51b35d8e6da5a3de681bf2cc969',1,'Stack']]]
];
