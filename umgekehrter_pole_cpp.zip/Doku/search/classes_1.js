var searchData=
[
  ['emptystackexception_51',['EmptyStackException',['../class_empty_stack_exception.html',1,'']]]
];
