var searchData=
[
  ['pop_24',['pop',['../class_stack.html#aa2ea0e8c3293648589dd734d52487408',1,'Stack']]],
  ['process_5fcalculation_25',['process_calculation',['../class_stack.html#a518f80c4a12e5c3a90ce1ab27b833b6a',1,'Stack']]],
  ['push_26',['push',['../class_stack.html#a45d42765eb8ca0bc43f0cbd8577c3a69',1,'Stack::push(const std::string &amp;single_op)'],['../class_stack.html#ace28110b50a0a2f4f3c8fd5263413661',1,'Stack::push(T val)']]]
];
