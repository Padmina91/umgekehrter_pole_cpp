var searchData=
[
  ['is_5fcorrect_5foperand_73',['is_correct_operand',['../class_stack.html#ac97e2661786fad259793eb6d5772bf10',1,'Stack']]],
  ['is_5fcorrect_5foperator_74',['is_correct_operator',['../class_stack.html#a9c96e262800ab3a5761be44758623322',1,'Stack']]],
  ['is_5fempty_75',['is_empty',['../class_stack.html#ae667e7ba22b4abd3158996ec17a712a4',1,'Stack']]]
];
