var searchData=
[
  ['both_5fare_5fspaces_64',['both_are_spaces',['../class_stack.html#ac221b727e4c2ac328b336f3f8562b507',1,'Stack']]]
];
