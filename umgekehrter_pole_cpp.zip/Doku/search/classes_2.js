var searchData=
[
  ['invaliddatatypeexception_52',['InvalidDataTypeException',['../class_invalid_data_type_exception.html',1,'']]],
  ['invalidnumberexception_53',['InvalidNumberException',['../class_invalid_number_exception.html',1,'']]],
  ['invalidresultexception_54',['InvalidResultException',['../class_invalid_result_exception.html',1,'']]],
  ['invalidsyntaxexception_55',['InvalidSyntaxException',['../class_invalid_syntax_exception.html',1,'']]]
];
