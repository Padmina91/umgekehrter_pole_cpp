var indexSectionsWithContent =
{
  0: "_bcdeghimprst",
  1: "deist",
  2: "emst",
  3: "bceghimprst",
  4: "_"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables"
};

