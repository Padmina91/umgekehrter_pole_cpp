var searchData=
[
  ['has_5fone_5felement_72',['has_one_element',['../class_stack.html#a688eb5c1beb18d6c20147f642110707d',1,'Stack']]]
];
