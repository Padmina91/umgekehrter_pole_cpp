var searchData=
[
  ['set_5fcalculation_28',['set_calculation',['../class_stack.html#a063f684a89b64fe6a248f371e61b1e46',1,'Stack']]],
  ['stack_29',['Stack',['../class_stack.html',1,'Stack&lt; T &gt;'],['../class_stack.html#a3e7368ea02d9564bd4385f1b78e14d9b',1,'Stack::Stack(std::string type_name)'],['../class_stack.html#a5fa95837cde7e826f2d7d43c32b331b5',1,'Stack::Stack(std::string calculation_input, const std::string &amp;type_name)']]],
  ['stack_2ehpp_30',['stack.hpp',['../stack_8hpp.html',1,'']]]
];
