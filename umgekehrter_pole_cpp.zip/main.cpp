//
// Created by Mina (Marina Inokuchi) on 18.05.2020.
// Padmina91 (GitHub)
//

#include "testdriver.hpp"

int main() {
    Testdriver::execute_tests();
}