# umgekehrter_pole_cpp
### My second C++ project for university

##### A calculator in Reverse Polish notation (https://en.wikipedia.org/wiki/Reverse_Polish_notation)

I am aware that I didn't consider some error cases, e.g. if the calculation with unsigned int causes
the result to fall below 0, which would result in an overflow. Or if calculating with ints results in too
large numbers that cause an overflow. However, this is only a program for learning C++, so it doesn't
need to take any possible error into consideration.


Mir ist bewusst, dass ich einige Randfälle nicht beachtet habe, z.B. wenn beim Rechnen mit unsigned int
im Laufe der Rechnung die 0 unterschritten wird und es somit zu einem Überlauf kommt. Oder wenn
es beim Rechnen mit int zu einer zu einer sehr großen (oder sehr kleinen negativen) Zahl kommt, die ebenso
einen Überlauf verursacht. Da ich dieses Programm jedoch nur dazu geschrieben habe, um C++ zu lernen, muss es nicht jeden Randfall
abfangen.